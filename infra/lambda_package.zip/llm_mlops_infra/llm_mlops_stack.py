from aws_cdk import (
    Stack,
    aws_s3 as s3,
    aws_iam as iam,
    aws_lambda as _lambda,
    aws_sagemaker as sagemaker,
    aws_ecr as ecr,
)
from constructs import Construct    

class LLmMlopsStack(Stack):

    def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # S3 Bucket for model artifacts
        model_bucket = s3.Bucket(self, "LLMModelBucket")

        # IAM Role for SageMaker
        sagemaker_role = iam.Role(
            self, "LLMSageMakerExecutionRole",
            assumed_by=iam.ServicePrincipal("sagemaker.amazonaws.com")
        )

        # Attach necessary policies to the role
        sagemaker_role.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name("AmazonSageMakerFullAccess")
        )
        model_bucket.grant_read(sagemaker_role) 
        sagemaker_role.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name("AmazonS3FullAccess")
        )       

        sagemaker_role.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name("CloudWatchFullAccess")
        )

        sagemaker_role.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name("AmazonEC2ContainerRegistryReadOnly")
        )         

        # ECR Repository for Docker Image
        ecr_repository = ecr.Repository.from_repository_name(
            self, "LLMECRRepository", "stablelm-inference"
        )

        ecr_repository.grant_pull(sagemaker_role)
        model_bucket.grant_read(sagemaker_role)

        # Lambda function to deploy SageMaker Endpoint
        lambda_fn = _lambda.Function(
            self, "DeployLLMSageMakerEndpoint",
            runtime=_lambda.Runtime.PYTHON_3_10,
            handler="deploy_sagemaker_endpoint.handler",
            code=_lambda.Code.from_asset("../lambda/lambda_package.zip"),
            memory_size=512,
        )

        # Grant necessary permissions to the Lambda function
        lambda_fn.add_to_role_policy(
            iam.PolicyStatement(
                actions=[
                    "sagemaker:CreateModel",
                    "sagemaker:CreateEndpointConfig",
                    "sagemaker:CreateEndpoint",
                    "sagemaker:DescribeEndpoint",
                    "sagemaker:DeleteModel",
                    "sagemaker:DeleteEndpointConfig",
                ],
                resources=["*"],
            )
        )    




          


        


